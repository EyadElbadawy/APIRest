package Files;

public class UserAndParameters {

    public static String AddUser() {
         String user = "{\"username\":\"admin\",\"password\":\"password123\"}";


        return user;
    }
public static String parameters() {
    String Parameter = "{\"firstname\":\"admin\",\"lastname\":\"password123\" , \"checkin\" , \"checkout\"}";

    return Parameter;
}



        }




